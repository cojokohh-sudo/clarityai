import { createBrowserRouter } from "react-router";
import { Layout } from "./components/Layout";
import { Home } from "./pages/Home";
import { DecisionTool } from "./pages/DecisionTool";
import { Pricing } from "./pages/Pricing";
import { NotFound } from "./pages/NotFound";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Layout,
    children: [
      { index: true, Component: Home },
      { path: "tool", Component: DecisionTool },
      { path: "pricing", Component: Pricing },
      { path: "*", Component: NotFound },
    ],
  },
]);
