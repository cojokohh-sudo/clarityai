
  # Clarity AI

  This is a code bundle for Clarity AI. The original project is available at https://www.figma.com/design/XKODk4jdk86A8tufDyvmls/Clarity-AI.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  